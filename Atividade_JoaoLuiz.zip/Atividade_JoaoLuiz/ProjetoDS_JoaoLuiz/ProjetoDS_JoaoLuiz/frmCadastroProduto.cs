﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_JoaoLuiz
{
    public partial class frmCadastroProduto : Form
    {
        public frmCadastroProduto()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCadastro_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            comando.CommandText = ("insert into produto(codBarra,Nome,dataValidade,uso,preco,bula,alergia) values (@codBarra,@Nome,@dataValidade,@uso,@preco,@bula,@alergia)");
            comando.Parameters.AddWithValue("@codBarra", txtCodBarra.Text);
            comando.Parameters.AddWithValue("@Nome", txtNome.Text);
            comando.Parameters.AddWithValue("@dataValidade", txtDataVal.Text);
            comando.Parameters.AddWithValue("@uso", txtUso.Text);
            comando.Parameters.AddWithValue("@preco", txtPreco.Text);
            comando.Parameters.AddWithValue("@bula", txtBula.Text);
            comando.Parameters.AddWithValue("@alergia", txtAlergia.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("Produto cadastrado com sucesso.");
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            txtCodBarra.Text = "";
            txtNome.Text = "";
            txtDataVal.Text = "";
            txtUso.Text = "";
            txtPreco.Text = "";
            txtBula.Text = "";
            txtAlergia.Text = "";
            txtCodBarra.Focus();
        }

        private void btnConsulta_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void btnConsulta_Click_1(object sender, EventArgs e)
        {
            ConsultarProduto consulta = new ConsultarProduto();
            consulta.Show();
            this.Hide();
        }
    }
}
