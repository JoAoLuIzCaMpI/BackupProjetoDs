﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_JoaoLuiz
{
    public partial class frmCliente : Form
    {
        public frmCliente()
        {
            InitializeComponent();
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            txtCPF.Text = "";
            txtNome.Text = "";
            txtIdade.Text = "";
            txtTelefone.Text = "";
            txtEmail.Text = "";
            txtAlergia.Text = "";
            txtDoenca.Text = "";
            txtCPF.Focus();
        }

        private void btnProduto_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            comando.CommandText = ("insert into cliente(CPF,nome,idade,telefone,email,doenca,alergia) values (@CPF,@nome,@idade,@telefone,@email,@doenca,@alergia)");
            comando.Parameters.AddWithValue("@CPF", txtCPF.Text);
            comando.Parameters.AddWithValue("@nome", txtNome.Text);
            comando.Parameters.AddWithValue("@idade", txtIdade.Text);
            comando.Parameters.AddWithValue("@telefone", txtTelefone.Text);
            comando.Parameters.AddWithValue("@email", txtEmail.Text);
            comando.Parameters.AddWithValue("@doenca", txtDoenca.Text);
            comando.Parameters.AddWithValue("@alergia", txtAlergia.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("Cliente cadastrado com sucesso.");
        }
    }
}
