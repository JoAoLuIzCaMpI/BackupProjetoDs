﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoDS_JoaoLuiz
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            frmLogin login = new frmLogin();
            login.Show();
            this.Hide();
            
        }

        private void btnUsuario_Click(object sender, EventArgs e)
        {
            frmCadastro usuario = new frmCadastro();
            usuario.Show();
            this.Hide();
        }

        private void btnAlterarSenha_Click(object sender, EventArgs e)
        {
            frmAlterarSenha senha = new frmAlterarSenha();
            senha.Show();
            this.Hide();  
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void btnConsulta_Click(object sender, EventArgs e)
        {
            ConsultarProduto consulta = new ConsultarProduto();
            consulta.Show();
            this.Hide();  
        }

        private void frmMenu_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "[" + DateTime.Now.ToShortDateString() + "]";
            toolStripStatusLabel2.Text = "[" + DateTime.Now.ToShortTimeString() + "]";
            toolStripStatusLabel3.Text = "[" + "Usuário logado: " + ClassVar.login + "]";
        }

        private void btnCliente_Click(object sender, EventArgs e)
        {
            frmCadastroProduto cadastro = new frmCadastroProduto();
            cadastro.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmItensVenda vendas = new frmItensVenda();
            vendas.Show();
            this.Hide();
        }

        private void btnCliente_Click_1(object sender, EventArgs e)
        {
            frmCliente cliente = new frmCliente();
            cliente.Show();
            this.Hide();
        }

        private void btnCliente_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void frmMenu_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                frmCliente cliente = new frmCliente();
                cliente.Show();
                this.Hide();
            }
        }
    }
}
