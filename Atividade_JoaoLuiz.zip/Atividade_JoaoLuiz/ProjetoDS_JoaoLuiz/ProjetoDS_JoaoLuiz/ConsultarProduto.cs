﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDS_JoaoLuiz
{
    public partial class ConsultarProduto : Form
    {
        public ConsultarProduto()
        {
            InitializeComponent();
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja excluir este produto?", "Exclusão de Dados", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd=''");
                MySqlCommand comando = new MySqlCommand();
                comando.Connection = conn;
                comando.CommandText = ("delete from produto where codBarra=@codBarra");
                comando.Parameters.AddWithValue("@codBarra", txtCodBarra.Text);
                conn.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("Foi realizado a exclusão deste produto");

                txtCodBarra.Text = "";
                txtNome.Text = "";
                txtDataVal.Text = "";
                txtUso.Text = "";
                txtPreco.Text = "";
                txtBula.Text = "";
                txtAlergia.Text = "";
                txtConsulta.Text = "Digite um nome para consulta";
                }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtConsulta_TextChanged(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd= '' ");
            String sql = "select * from produto where upper(Nome) like '%" +  txtConsulta.Text + "%'";
            MySqlDataAdapter da = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DataTable dt = new DataTable();
            dt = ds.Tables[0];
            DGVConsulta.DataSource = dt;
        }

        private void DGVConsulta_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtCodBarra.Text = DGVConsulta.CurrentRow.Cells[0].Value.ToString();
            txtNome.Text = DGVConsulta.CurrentRow.Cells[1].Value.ToString();
            txtDataVal.Text = DGVConsulta.CurrentRow.Cells[2].Value.ToString();
            txtUso.Text = DGVConsulta.CurrentRow.Cells[3].Value.ToString();
            txtPreco.Text = DGVConsulta.CurrentRow.Cells[4].Value.ToString();
            txtBula.Text = DGVConsulta.CurrentRow.Cells[5].Value.ToString();
            txtAlergia.Text = DGVConsulta.CurrentRow.Cells[6].Value.ToString();
        }

        private void ConsultarProduto_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                txtNome.Enabled = true;
                txtDataVal.Enabled = true;
                txtUso.Enabled = true;
                txtPreco.Enabled = true;
                txtBula.Enabled = true;
                txtAlergia.Enabled = true;
                txtCodBarra.Focus();
            }
        }

        private void btnConsulta_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost; database=bdfarmacia; uid=root; pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            comando.CommandText = ("update produto set Nome=@Nome, dataValidade=@dataValidade, uso=@uso, preco=@preco, bula=@bula, alergia=@alergia");
            comando.Parameters.AddWithValue("@codBarra", txtCodBarra.Text);
            comando.Parameters.AddWithValue("@Nome", txtNome.Text);
            comando.Parameters.AddWithValue("@dataValidade", txtDataVal.Text);
            comando.Parameters.AddWithValue("@uso", txtUso.Text);
            comando.Parameters.AddWithValue("@preco", txtPreco.Text);
            comando.Parameters.AddWithValue("@bula", txtBula.Text);
            comando.Parameters.AddWithValue("@alergia", txtAlergia.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("Produto alterado com sucesso.");
        }

        private void DGVConsulta_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
