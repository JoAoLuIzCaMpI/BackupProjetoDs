﻿
namespace ProjetoDS_JoaoLuiz
{
    partial class frmCadastroProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCadastro = new System.Windows.Forms.Button();
            this.btnApagar = new System.Windows.Forms.Button();
            this.txtCodBarra = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtDataVal = new System.Windows.Forms.TextBox();
            this.txtUso = new System.Windows.Forms.TextBox();
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.txtBula = new System.Windows.Forms.TextBox();
            this.txtAlergia = new System.Windows.Forms.TextBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnConsulta = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCadastro
            // 
            this.btnCadastro.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnCadastro.ForeColor = System.Drawing.SystemColors.Control;
            this.btnCadastro.Location = new System.Drawing.Point(399, 598);
            this.btnCadastro.Name = "btnCadastro";
            this.btnCadastro.Size = new System.Drawing.Size(193, 46);
            this.btnCadastro.TabIndex = 1;
            this.btnCadastro.Text = "CADASTRAR";
            this.btnCadastro.UseVisualStyleBackColor = false;
            this.btnCadastro.Click += new System.EventHandler(this.btnCadastro_Click);
            // 
            // btnApagar
            // 
            this.btnApagar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnApagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnApagar.ForeColor = System.Drawing.SystemColors.Control;
            this.btnApagar.Location = new System.Drawing.Point(543, 677);
            this.btnApagar.Name = "btnApagar";
            this.btnApagar.Size = new System.Drawing.Size(193, 38);
            this.btnApagar.TabIndex = 3;
            this.btnApagar.Text = "APAGAR";
            this.btnApagar.UseVisualStyleBackColor = false;
            this.btnApagar.Click += new System.EventHandler(this.btnApagar_Click);
            // 
            // txtCodBarra
            // 
            this.txtCodBarra.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodBarra.Location = new System.Drawing.Point(193, 269);
            this.txtCodBarra.Multiline = true;
            this.txtCodBarra.Name = "txtCodBarra";
            this.txtCodBarra.Size = new System.Drawing.Size(219, 20);
            this.txtCodBarra.TabIndex = 4;
            this.txtCodBarra.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtNome
            // 
            this.txtNome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNome.Location = new System.Drawing.Point(532, 269);
            this.txtNome.Multiline = true;
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(219, 20);
            this.txtNome.TabIndex = 5;
            // 
            // txtDataVal
            // 
            this.txtDataVal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDataVal.Location = new System.Drawing.Point(848, 269);
            this.txtDataVal.Multiline = true;
            this.txtDataVal.Name = "txtDataVal";
            this.txtDataVal.Size = new System.Drawing.Size(186, 20);
            this.txtDataVal.TabIndex = 6;
            // 
            // txtUso
            // 
            this.txtUso.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUso.Location = new System.Drawing.Point(269, 374);
            this.txtUso.Multiline = true;
            this.txtUso.Name = "txtUso";
            this.txtUso.Size = new System.Drawing.Size(219, 20);
            this.txtUso.TabIndex = 7;
            // 
            // txtPreco
            // 
            this.txtPreco.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPreco.Location = new System.Drawing.Point(793, 374);
            this.txtPreco.Multiline = true;
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.Size = new System.Drawing.Size(219, 20);
            this.txtPreco.TabIndex = 8;
            // 
            // txtBula
            // 
            this.txtBula.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBula.Location = new System.Drawing.Point(269, 500);
            this.txtBula.Multiline = true;
            this.txtBula.Name = "txtBula";
            this.txtBula.Size = new System.Drawing.Size(219, 20);
            this.txtBula.TabIndex = 9;
            // 
            // txtAlergia
            // 
            this.txtAlergia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAlergia.Location = new System.Drawing.Point(793, 500);
            this.txtAlergia.Multiline = true;
            this.txtAlergia.Name = "txtAlergia";
            this.txtAlergia.Size = new System.Drawing.Size(219, 20);
            this.txtAlergia.TabIndex = 10;
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnSair.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSair.Location = new System.Drawing.Point(1050, 689);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(198, 32);
            this.btnSair.TabIndex = 11;
            this.btnSair.Text = "MENU";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjetoDS_JoaoLuiz.Properties.Resources.CadastroProduto;
            this.pictureBox1.Location = new System.Drawing.Point(1, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1309, 759);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnConsulta
            // 
            this.btnConsulta.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnConsulta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnConsulta.ForeColor = System.Drawing.SystemColors.Control;
            this.btnConsulta.Location = new System.Drawing.Point(664, 598);
            this.btnConsulta.Name = "btnConsulta";
            this.btnConsulta.Size = new System.Drawing.Size(198, 46);
            this.btnConsulta.TabIndex = 12;
            this.btnConsulta.Text = "CONSULTAR";
            this.btnConsulta.UseVisualStyleBackColor = false;
            this.btnConsulta.Click += new System.EventHandler(this.btnConsulta_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(773, 456);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 13;
            // 
            // frmCadastroProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1282, 757);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnConsulta);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.txtAlergia);
            this.Controls.Add(this.txtBula);
            this.Controls.Add(this.txtPreco);
            this.Controls.Add(this.txtUso);
            this.Controls.Add(this.txtDataVal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtCodBarra);
            this.Controls.Add(this.btnApagar);
            this.Controls.Add(this.btnCadastro);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmCadastroProduto";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnCadastro;
        private System.Windows.Forms.Button btnApagar;
        private System.Windows.Forms.TextBox txtCodBarra;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtDataVal;
        private System.Windows.Forms.TextBox txtUso;
        private System.Windows.Forms.TextBox txtPreco;
        private System.Windows.Forms.TextBox txtBula;
        private System.Windows.Forms.TextBox txtAlergia;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnConsulta;
        private System.Windows.Forms.Label label1;
    }
}