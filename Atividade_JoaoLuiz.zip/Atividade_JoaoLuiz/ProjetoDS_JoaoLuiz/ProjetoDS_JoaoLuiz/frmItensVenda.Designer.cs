﻿
namespace ProjetoDS_JoaoLuiz
{
    partial class frmItensVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txtTotalPagar = new System.Windows.Forms.TextBox();
            this.mskCpfCliente = new System.Windows.Forms.MaskedTextBox();
            this.btnMenu = new System.Windows.Forms.Button();
            this.mskData = new System.Windows.Forms.MaskedTextBox();
            this.btnGravarItens = new System.Windows.Forms.Button();
            this.btnTotalItens = new System.Windows.Forms.Button();
            this.btnIniciarVenda = new System.Windows.Forms.Button();
            this.txtValorVenda = new System.Windows.Forms.TextBox();
            this.DGV_ItensVenda = new System.Windows.Forms.DataGridView();
            this.codItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codBarra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IdVenda = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Descricao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valorItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantidade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCodVendas = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnTotal = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.DGV_Produtos = new System.Windows.Forms.DataGridView();
            this.btnAdicao = new System.Windows.Forms.Button();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtProduto = new System.Windows.Forms.TextBox();
            this.txtValorUnitario = new System.Windows.Forms.TextBox();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.txtCod = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_ItensVenda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Produtos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 2);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1719, 978);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.txtTotalPagar);
            this.tabPage1.Controls.Add(this.mskCpfCliente);
            this.tabPage1.Controls.Add(this.btnMenu);
            this.tabPage1.Controls.Add(this.mskData);
            this.tabPage1.Controls.Add(this.btnGravarItens);
            this.tabPage1.Controls.Add(this.btnTotalItens);
            this.tabPage1.Controls.Add(this.btnIniciarVenda);
            this.tabPage1.Controls.Add(this.txtValorVenda);
            this.tabPage1.Controls.Add(this.DGV_ItensVenda);
            this.tabPage1.Controls.Add(this.txtCodVendas);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(1711, 949);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Vendas";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(536, 458);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(359, 24);
            this.comboBox1.TabIndex = 15;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // txtTotalPagar
            // 
            this.txtTotalPagar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTotalPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtTotalPagar.Location = new System.Drawing.Point(499, 873);
            this.txtTotalPagar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTotalPagar.Multiline = true;
            this.txtTotalPagar.Name = "txtTotalPagar";
            this.txtTotalPagar.Size = new System.Drawing.Size(137, 25);
            this.txtTotalPagar.TabIndex = 14;
            // 
            // mskCpfCliente
            // 
            this.mskCpfCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.mskCpfCliente.Location = new System.Drawing.Point(163, 452);
            this.mskCpfCliente.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mskCpfCliente.Mask = "000.000.000-00";
            this.mskCpfCliente.Name = "mskCpfCliente";
            this.mskCpfCliente.Size = new System.Drawing.Size(276, 30);
            this.mskCpfCliente.TabIndex = 13;
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnMenu.ForeColor = System.Drawing.SystemColors.Control;
            this.btnMenu.Location = new System.Drawing.Point(1421, 898);
            this.btnMenu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(264, 39);
            this.btnMenu.TabIndex = 12;
            this.btnMenu.Text = "MENU";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.button1_Click);
            // 
            // mskData
            // 
            this.mskData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mskData.Enabled = false;
            this.mskData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.mskData.Location = new System.Drawing.Point(432, 286);
            this.mskData.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mskData.Mask = "00/00/0000";
            this.mskData.Name = "mskData";
            this.mskData.Size = new System.Drawing.Size(187, 23);
            this.mskData.TabIndex = 10;
            this.mskData.ValidatingType = typeof(System.DateTime);
            // 
            // btnGravarItens
            // 
            this.btnGravarItens.BackColor = System.Drawing.Color.Black;
            this.btnGravarItens.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnGravarItens.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnGravarItens.Location = new System.Drawing.Point(1229, 678);
            this.btnGravarItens.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGravarItens.Name = "btnGravarItens";
            this.btnGravarItens.Size = new System.Drawing.Size(239, 46);
            this.btnGravarItens.TabIndex = 9;
            this.btnGravarItens.Text = "Gravar Itens";
            this.btnGravarItens.UseVisualStyleBackColor = false;
            this.btnGravarItens.Click += new System.EventHandler(this.btnTotalPagar_Click);
            // 
            // btnTotalItens
            // 
            this.btnTotalItens.BackColor = System.Drawing.Color.Black;
            this.btnTotalItens.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnTotalItens.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnTotalItens.Location = new System.Drawing.Point(211, 858);
            this.btnTotalItens.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTotalItens.Name = "btnTotalItens";
            this.btnTotalItens.Size = new System.Drawing.Size(209, 49);
            this.btnTotalItens.TabIndex = 8;
            this.btnTotalItens.Text = "Total à pagar";
            this.btnTotalItens.UseVisualStyleBackColor = false;
            this.btnTotalItens.Click += new System.EventHandler(this.btnGravarItens_Click);
            // 
            // btnIniciarVenda
            // 
            this.btnIniciarVenda.BackColor = System.Drawing.Color.Black;
            this.btnIniciarVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnIniciarVenda.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnIniciarVenda.Location = new System.Drawing.Point(983, 345);
            this.btnIniciarVenda.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnIniciarVenda.Name = "btnIniciarVenda";
            this.btnIniciarVenda.Size = new System.Drawing.Size(245, 50);
            this.btnIniciarVenda.TabIndex = 7;
            this.btnIniciarVenda.Text = "Iniciar Venda";
            this.btnIniciarVenda.UseVisualStyleBackColor = false;
            this.btnIniciarVenda.Click += new System.EventHandler(this.btnFinalizarVenda_Click);
            // 
            // txtValorVenda
            // 
            this.txtValorVenda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtValorVenda.Location = new System.Drawing.Point(499, 875);
            this.txtValorVenda.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtValorVenda.Multiline = true;
            this.txtValorVenda.Name = "txtValorVenda";
            this.txtValorVenda.Size = new System.Drawing.Size(137, 25);
            this.txtValorVenda.TabIndex = 6;
            // 
            // DGV_ItensVenda
            // 
            this.DGV_ItensVenda.BackgroundColor = System.Drawing.Color.DarkOliveGreen;
            this.DGV_ItensVenda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_ItensVenda.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.codItem,
            this.codBarra,
            this.IdVenda,
            this.Descricao,
            this.valorItem,
            this.Quantidade});
            this.DGV_ItensVenda.Location = new System.Drawing.Point(95, 582);
            this.DGV_ItensVenda.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.DGV_ItensVenda.Name = "DGV_ItensVenda";
            this.DGV_ItensVenda.RowHeadersWidth = 51;
            this.DGV_ItensVenda.Size = new System.Drawing.Size(1075, 185);
            this.DGV_ItensVenda.TabIndex = 5;
            this.DGV_ItensVenda.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_ItensVenda_CellContentClick);
            // 
            // codItem
            // 
            this.codItem.HeaderText = "Cód. do Item";
            this.codItem.MinimumWidth = 6;
            this.codItem.Name = "codItem";
            this.codItem.Width = 125;
            // 
            // codBarra
            // 
            this.codBarra.HeaderText = "Cód. de Barra";
            this.codBarra.MinimumWidth = 6;
            this.codBarra.Name = "codBarra";
            this.codBarra.Width = 125;
            // 
            // IdVenda
            // 
            this.IdVenda.HeaderText = "Id da Venda";
            this.IdVenda.MinimumWidth = 6;
            this.IdVenda.Name = "IdVenda";
            this.IdVenda.Width = 125;
            // 
            // Descricao
            // 
            this.Descricao.HeaderText = "Descrição";
            this.Descricao.MinimumWidth = 6;
            this.Descricao.Name = "Descricao";
            this.Descricao.Width = 125;
            // 
            // valorItem
            // 
            this.valorItem.HeaderText = "Valor do Item";
            this.valorItem.MinimumWidth = 6;
            this.valorItem.Name = "valorItem";
            this.valorItem.Width = 125;
            // 
            // Quantidade
            // 
            this.Quantidade.HeaderText = "Quantidade";
            this.Quantidade.MinimumWidth = 6;
            this.Quantidade.Name = "Quantidade";
            this.Quantidade.Width = 125;
            // 
            // txtCodVendas
            // 
            this.txtCodVendas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodVendas.Enabled = false;
            this.txtCodVendas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtCodVendas.Location = new System.Drawing.Point(125, 286);
            this.txtCodVendas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCodVendas.Multiline = true;
            this.txtCodVendas.Name = "txtCodVendas";
            this.txtCodVendas.Size = new System.Drawing.Size(179, 25);
            this.txtCodVendas.TabIndex = 2;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProjetoDS_JoaoLuiz.Properties.Resources.Vendas;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1700, 946);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnTotal);
            this.tabPage2.Controls.Add(this.btnSair);
            this.tabPage2.Controls.Add(this.DGV_Produtos);
            this.tabPage2.Controls.Add(this.btnAdicao);
            this.tabPage2.Controls.Add(this.txtTotal);
            this.tabPage2.Controls.Add(this.txtProduto);
            this.tabPage2.Controls.Add(this.txtValorUnitario);
            this.tabPage2.Controls.Add(this.txtQuantidade);
            this.tabPage2.Controls.Add(this.txtCod);
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(1711, 949);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Produtos";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnTotal
            // 
            this.btnTotal.BackColor = System.Drawing.Color.Black;
            this.btnTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotal.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnTotal.Location = new System.Drawing.Point(371, 859);
            this.btnTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(153, 60);
            this.btnTotal.TabIndex = 13;
            this.btnTotal.Text = "Total";
            this.btnTotal.UseVisualStyleBackColor = false;
            this.btnTotal.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnSair.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSair.Location = new System.Drawing.Point(1396, 880);
            this.btnSair.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(264, 39);
            this.btnSair.TabIndex = 12;
            this.btnSair.Text = "MENU";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // DGV_Produtos
            // 
            this.DGV_Produtos.BackgroundColor = System.Drawing.Color.DarkOliveGreen;
            this.DGV_Produtos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Produtos.Location = new System.Drawing.Point(43, 240);
            this.DGV_Produtos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.DGV_Produtos.Name = "DGV_Produtos";
            this.DGV_Produtos.RowHeadersWidth = 51;
            this.DGV_Produtos.Size = new System.Drawing.Size(1259, 334);
            this.DGV_Produtos.TabIndex = 7;
            this.DGV_Produtos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_Produtos_CellClick);
            this.DGV_Produtos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_Produtos_CellContentClick);
            // 
            // btnAdicao
            // 
            this.btnAdicao.BackColor = System.Drawing.Color.Black;
            this.btnAdicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.btnAdicao.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAdicao.Location = new System.Drawing.Point(960, 859);
            this.btnAdicao.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAdicao.Name = "btnAdicao";
            this.btnAdicao.Size = new System.Drawing.Size(93, 60);
            this.btnAdicao.TabIndex = 6;
            this.btnAdicao.Text = "+";
            this.btnAdicao.UseVisualStyleBackColor = false;
            this.btnAdicao.Click += new System.EventHandler(this.btnAdicao_Click);
            // 
            // txtTotal
            // 
            this.txtTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTotal.Location = new System.Drawing.Point(119, 866);
            this.txtTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTotal.Multiline = true;
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(135, 25);
            this.txtTotal.TabIndex = 5;
            // 
            // txtProduto
            // 
            this.txtProduto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtProduto.Location = new System.Drawing.Point(323, 677);
            this.txtProduto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtProduto.Multiline = true;
            this.txtProduto.Name = "txtProduto";
            this.txtProduto.Size = new System.Drawing.Size(268, 25);
            this.txtProduto.TabIndex = 4;
            this.txtProduto.TextChanged += new System.EventHandler(this.txtProduto_TextChanged);
            // 
            // txtValorUnitario
            // 
            this.txtValorUnitario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtValorUnitario.Enabled = false;
            this.txtValorUnitario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtValorUnitario.Location = new System.Drawing.Point(889, 677);
            this.txtValorUnitario.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtValorUnitario.Multiline = true;
            this.txtValorUnitario.Name = "txtValorUnitario";
            this.txtValorUnitario.Size = new System.Drawing.Size(128, 25);
            this.txtValorUnitario.TabIndex = 3;
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtQuantidade.Location = new System.Drawing.Point(700, 677);
            this.txtQuantidade.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtQuantidade.Multiline = true;
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(115, 25);
            this.txtQuantidade.TabIndex = 2;
            this.txtQuantidade.Text = "1";
            // 
            // txtCod
            // 
            this.txtCod.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCod.Enabled = false;
            this.txtCod.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtCod.Location = new System.Drawing.Point(107, 677);
            this.txtCod.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCod.Multiline = true;
            this.txtCod.Name = "txtCod";
            this.txtCod.Size = new System.Drawing.Size(115, 25);
            this.txtCod.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::ProjetoDS_JoaoLuiz.Properties.Resources.Produtos1;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1705, 946);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // frmItensVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1707, 970);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmItensVenda";
            this.Load += new System.EventHandler(this.frmItensVenda_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_ItensVenda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Produtos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnAdicao;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtProduto;
        private System.Windows.Forms.TextBox txtValorUnitario;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.TextBox txtCod;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView DGV_Produtos;
        private System.Windows.Forms.Button btnGravarItens;
        private System.Windows.Forms.Button btnTotalItens;
        private System.Windows.Forms.Button btnIniciarVenda;
        private System.Windows.Forms.TextBox txtValorVenda;
        private System.Windows.Forms.DataGridView DGV_ItensVenda;
        private System.Windows.Forms.TextBox txtCodVendas;
        private System.Windows.Forms.MaskedTextBox mskData;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.MaskedTextBox mskCpfCliente;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.TextBox txtTotalPagar;
        private System.Windows.Forms.DataGridViewTextBoxColumn codItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn codBarra;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdVenda;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descricao;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantidade;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}